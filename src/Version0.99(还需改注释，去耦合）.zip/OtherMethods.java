import java.util.*;

import javax.swing.JLabel;
public class OtherMethods {
	public static boolean checkEmail(String s) {
		char[] ch = s.toCharArray();
		for(int i=0;i<ch.length;i++) {
			//only contain '@', '.', letter or digit
			if(!Character.isLetterOrDigit(ch[i]) && ch[i]!='.' && ch[i]!='@')
				return false;
		}
		for(int i=0;i<ch.length;i++) {  
			//must contain'@', after '@�� there must be a '.'
			if(ch[i]=='@') {
				for(int j=i;j<ch.length;j++) {
					if (ch[j]=='.') return true;
				}
				return false;
			}
		}
		return false;
	}
	public static void lightBlink(JLabel[] lightLabels,int n) {
		TimerTask task=new TimerTask(){
			   boolean flag = false;
			   Date date = new Date();
			   long startTime = date.getTime();
			   @Override
			   public void run() {
				  if(flag) {
					  lightLabels[n].setVisible(false);
					  flag = !flag;
				  }
				  else {
					  lightLabels[n].setVisible(true);
					  flag = !flag;
				  }
				  Date newDate = new Date();
				  if(newDate.getTime()-startTime>500) {
					  this.cancel();
					  System.gc();
				  }
			   }
			         
		};
			        Timer timer=new Timer();
			        timer.schedule(task, 0,500);  //0��ʶҪ�ӳٵ�ʱ�䣬5000ָ����
	}
	public static void main(String args[]) {
		System.out.println(checkEmail("635310038@qq.com"));
		System.out.println(checkEmail("434890@qq"));
		System.out.println(checkEmail("635310038qq.com"));
	}
	
}
