import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.*;
import java.util.Date;

public class CoreMethods {
	public static int overTime = 30;
	public static void swipeCardGeneral(InformationSystem system,JTextArea txtrMessages,
			JTextField textField,String userLastInput,JLabel lblUseTime) {
		
	}
	
	public static void swipeCard(InformationSystem system, String userInput,
			JTextArea txtrMessages,JLabel lblUseTime,Timer timer,
			JLabel[] photoLabels,JLabel[] lightLabels){
			//loc is 0,1,2,3; while 0 stands for not chosen an location yet, 
			//loc-- is used to match the index of 2-dimensional array 	
			if(!OtherMethods.checkEmail(userInput)) { //input valid
				txtrMessages.setText("Message:" + '\n'+
						"Your input is NOT Valid!!" + '\n' +" Please input again!");
				return;
			}
			if(system.getCurrentLoc()==0) {
				txtrMessages.setText("Please choose a location first!");
				return;
			}
			ArrayList<User> list = system.getlist();
			for(User user:list) {
				if(user.getEmail().equals(userInput)) {
					//user name is found,check if the user is forbiddened
					if(user.isForbiddened()) {
						txtrMessages.setText("You have unpaid fine!" + '\n' 
									+"Please contact administrator!");
						return;
					}
					//paid(valid user)
					else {  
						if(user.isRiding()==true) { //park
							park(system.getCurrentLoc()-1,system,user,txtrMessages,lblUseTime,timer,photoLabels,lightLabels);
							return;
						}
						else { //pick up
							Date date = new Date();
							user.setLastStartTime(date.getTime());
							System.out.println(date.getTime());
							//TimerTest t = new TimerTest();
							//t.start(lblUseTime, user.getLastStartTime());
							
							pickup(system.getCurrentLoc()-1,system,user,txtrMessages,lblUseTime,timer,photoLabels,lightLabels);
							return;
						}
					}
				}
			}
			//User Not Found
			txtrMessages.setText("User Not Found!");
	}
	
	public static void pickup(int loc,InformationSystem system,User user,JTextArea txtrMessages,JLabel lblUseTime,Timer timer,JLabel[] photoLabels,JLabel[] lightLabels) {
		system.setCurrentLoc(0); //clear cache
		boolean[][] freespace = system.getFreeSpace();
		for(int i=0;i<8;i++) {
			if(freespace[loc][i]) {
				freespace[loc][i]=!freespace[loc][i];
				photoLabels[i].setVisible(false);   //scooter image disappear
				OtherMethods.lightBlink(lightLabels, i); //blink light
				txtrMessages.setText("Pick up car success!");
				//Timer
				Date date = new Date();
				timer.restart();
				//set Flag
				user.setRiding(true); // why this is valid??
				//glistening
				ObjectIO.writeObjectToFile(system);
				return;
			}
		}
		txtrMessages.setText("Pick up car failed, not enough cars");
	}
	
	public static void park(int loc,InformationSystem system,User user,JTextArea txtrMessages,JLabel lblUseTime,Timer timer,JLabel[] photoLabels,JLabel[] lightLabels) {
		system.setCurrentLoc(0);  //clear cache
		boolean[][] freespace = system.getFreeSpace();
		//for(int i=0;i<8;i++) {System.out.print(freespace[i]+" ");}
		for(int i=7;i>=0;i--) {
			if(!freespace[loc][i]) {
				freespace[loc][i]=!freespace[loc][i];
				photoLabels[i].setVisible(true);    //scooter image appear
				OtherMethods.lightBlink(lightLabels, i);   //blink light
				user.setRiding(false);
				//Timer
				//System.out.println(timer==null);
				timer.stop();
				Date date = new Date();
				long t = (date.getTime()-user.getLastStartTime())/1000;
				System.out.println(date.getTime());
				System.out.println(user.getLastStartTime());
				lblUseTime.setText("Ride finish.Total time is: "+ t + " seconds");
				//If this day is the first day of the month, clear the monthUseTime
				Calendar cal = Calendar.getInstance();
				if(cal.get(Calendar.DAY_OF_MONTH)==1) 
				{
					user.setMonthUseTime(0);				
				}
				user.setMonthUseTime(user.getMonthUseTime()+t);
				if(t>=overTime) {
					txtrMessages.setText("park car success! "
							+'\n'+ "However, since you ride more "+'\n'
									+ "than 30s, you are forbiddened now."+'\n'+
							"Please pay the fine.");
					user.setForbid(true);
				}
				else txtrMessages.setText("park car success!");
				ObjectIO.writeObjectToFile(system);
				return;
			}
		}
		txtrMessages.setText("park car failed, not enough freespaces available");
	}
	
	public static void viewFreeSpace(int loc,InformationSystem system,JTextArea txtrMessages,JLabel[] photoLabels) {
		boolean[][] freespace = system.getFreeSpace();
		loc--;
		int freeAmount = 0;
		for(int i=0;i<=7;i++) {
			if(freespace[loc][i]) {
				freeAmount++;
				photoLabels[i].setVisible(true);
			}
			else {
				photoLabels[i].setVisible(false);
			}
		}
		if(loc==0) txtrMessages.setText("Message:"+  '\n' +
				 "Location A has " + freeAmount + " free spaces," + '\n' +
				(8-freeAmount) + " already using.");
		else if(loc==1) txtrMessages.setText("Message:"+  '\n' +
				 "Location B has " + freeAmount + " free spaces,"+'\n' +
		 (8-freeAmount) + " already using.");
		else if(loc==2) txtrMessages.setText("Message:" + '\n'
				+ "Location C has " + freeAmount + " free spaces," +'\n' +
		(8-freeAmount) + " already using.");	
		else txtrMessages.setText("Unexpected error"); //supposed not to executed here
	}
	
	public static void addUser(JTextField userInputField,JTextArea txtrInformation ) {
		InformationSystem system = (InformationSystem)ObjectIO.readObjectFromFile();
		if(OtherMethods.checkEmail(userInputField.getText())) {
			ArrayList<User> list = system.getlist();
			for(User user:list) {
				if(user.getEmail().equals(userInputField.getText())) {
					txtrInformation.setText("User already exist!");
					return;
				}
			}			
			User user = new User(userInputField.getText());
			system.add(user);
			ObjectIO.writeObjectToFile(system);
			txtrInformation.setText("Add user success!");
		}
		else {
			//invalid input
			txtrInformation.setText("Invalid Email Address!Please Input again!");
		}
	}
	
	public static void removeUser(JTextField userInputField,JTextArea txtrInformation ) {
		InformationSystem system = (InformationSystem)ObjectIO.readObjectFromFile();
		if(OtherMethods.checkEmail(userInputField.getText())) { 
			//valid input
			ArrayList<User> list = system.getlist();
			for(User user:list) {
				if(user.getEmail().equals(userInputField.getText())) {
					system.remove(user);
					ObjectIO.writeObjectToFile(system);
					txtrInformation.setText("Remove user success!");
					return;
				}
			}
			//User Not Found
			txtrInformation.setText("User Not Found!");
		}
		else {
			txtrInformation.setText("Invalid Email Address!Please Input again!");
		}
	}
	
	public static void checkUser(JTextField userInputField,JTextArea txtrInformation) {
		InformationSystem system = (InformationSystem)ObjectIO.readObjectFromFile();
		if(OtherMethods.checkEmail(userInputField.getText())) { 
			//valid input
			ArrayList<User> list = system.getlist();
			for(User user:list) {
				if(user.getEmail().equals(userInputField.getText())) {
					txtrInformation.setText(user.toString());
					return;
				}
			}
			//User Not Found
			txtrInformation.setText("User Not Found!");
		}
		else {
			txtrInformation.setText("Invalid Email Address!Please Input again!");
		}
	}
	
	public static void payfine(JTextField userInputField,JTextArea txtrInformation) {
		InformationSystem system = (InformationSystem)ObjectIO.readObjectFromFile();
		if(OtherMethods.checkEmail(userInputField.getText())) { 
			//valid input
			ArrayList<User> list = system.getlist();
			for(User user:list) {
				if(user.getEmail().equals(userInputField.getText())) {
					user.setForbid(false);
					ObjectIO.writeObjectToFile(system);
					txtrInformation.setText("User:"+user.getEmail()+"\nhas successfully paid the fine!");
					return;
				}
			}
			//User Not Found
			txtrInformation.setText("User Not Found!");
		}
		else {
			txtrInformation.setText("Invalid Email Address!Please Input again!");
		}
	}
	
	public static void clearAllFines(JTextArea txtrInformation) {
		InformationSystem system = (InformationSystem)ObjectIO.readObjectFromFile();
		ArrayList<User> list = system.getlist();
		for(User user:list) {
			user.setForbid(false);
		}
		ObjectIO.writeObjectToFile(system);
		txtrInformation.setText("All the fines have been cleared!");
	}
	
	public static void searchUnpaidUsers(JTextArea txtrInformation) {
		InformationSystem system = (InformationSystem)ObjectIO.readObjectFromFile();
		ArrayList<User> list = system.getlist();
		String s = "Unpaied users' emails:" +'\n';
		for(User user:list) {
			if(user.isForbiddened()) {
				s = s + user.getEmail() +'\n';
			}
		}
		txtrInformation.setText(s);
	}
	
}
