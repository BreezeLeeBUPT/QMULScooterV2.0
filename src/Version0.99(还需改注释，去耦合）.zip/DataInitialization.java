
public class DataInitialization {
	public static void main(String args[]) {
		InformationSystem i = new InformationSystem();
		i.initlizeFreeSpace();
		ObjectIO.writeObjectToFile(i);
	}
}
